package com.example.android.ichat_alura.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.android.ichat_alura.app.ChatApplication;
import com.example.android.ichat_alura.R;
import com.example.android.ichat_alura.adapter.MensagensAdapter;
import com.example.android.ichat_alura.callback.EnviarMensagemCallback;
import com.example.android.ichat_alura.callback.OuvirMensagemCallback;
import com.example.android.ichat_alura.component.ChatComponent;
import com.example.android.ichat_alura.model.Mensagem;
import com.example.android.ichat_alura.service.ChatService;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;

public class MainActivity extends AppCompatActivity {

    private final int idDoCliente = 1;
    private List<Mensagem> listaMensagem;

    @BindView(R.id.textoEnviar)
    public EditText editTextMensagem;
    @BindView(R.id.botaoEnviar)
    public Button buttonEnviar;
    @BindView(R.id.listaMensagens)
    public RecyclerView rcVListaMensagem;


    @Inject
    ChatService chatService;

    private ChatComponent component;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        listaMensagem = new ArrayList<>();

        MensagensAdapter adapter = new MensagensAdapter(idDoCliente, listaMensagem, this);
        rcVListaMensagem.setLayoutManager(new LinearLayoutManager(this));
        rcVListaMensagem.setAdapter(adapter);

        ChatApplication app = (ChatApplication)getApplication();
        component = app.getComponent();
        component.inject(this);

    }

    @OnClick(R.id.botaoEnviar)
    public void enviarMensagem(){
        chatService.enviar(new Mensagem(idDoCliente, editTextMensagem.getText().toString())).enqueue(new EnviarMensagemCallback());
    }

    public void adicionaALista(Mensagem mensagem) {
        listaMensagem.add(mensagem);
        MensagensAdapter adapter = new MensagensAdapter(idDoCliente, listaMensagem, this);
        rcVListaMensagem.setAdapter(adapter);
        ouvirMensagem();
    }

    public void ouvirMensagem(){
        Call<Mensagem> call = chatService.ouvirMensagens();
        call.enqueue(new OuvirMensagemCallback(this));
    }
}

package com.example.android.ichat_alura.callback;

import com.example.android.ichat_alura.activity.MainActivity;
import com.example.android.ichat_alura.model.Mensagem;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OuvirMensagemCallback implements Callback<Mensagem> {

    private MainActivity activity;

    public OuvirMensagemCallback(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public void onResponse(Call<Mensagem> call, Response<Mensagem> response) {
        if (response.isSuccessful()) {
            Mensagem mensagem = response.body();
            activity.adicionaALista(mensagem);
        }
    }

    @Override
    public void onFailure(Call<Mensagem> call, Throwable t) {
        activity.ouvirMensagem();
    }
}

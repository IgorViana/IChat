package com.example.android.ichat_alura.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.ichat_alura.R;
import com.example.android.ichat_alura.model.Mensagem;

import java.util.List;

public class MensagensAdapter extends RecyclerView.Adapter<MensagensAdapter.MyViewHolder> {
    private List<Mensagem> mensagens;
    private Context context;
    private int idDoCliente;

    public MensagensAdapter(int idDoCliente, List<Mensagem> mensagens, Context context) {
        this.idDoCliente = idDoCliente;
        this.mensagens = mensagens;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_mensagem, viewGroup, false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder viewHolder, int i) {
        Mensagem mensagem = mensagens.get(i);
        if(mensagem.getId() != idDoCliente) {
            viewHolder.itemView.setBackgroundColor(Color.CYAN);
        }
        viewHolder.textoMensagem.setText(mensagem.getTexto());
    }

    @Override
    public int getItemCount() {
        return mensagens.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        private final TextView textoMensagem;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textoMensagem = itemView.findViewById(R.id.textoMensagem);
        }
    }
}
